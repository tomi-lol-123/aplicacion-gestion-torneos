package gui;

import javax.swing.*;
import java.awt.*;

public class CrearJugador extends JPanel {

    public static final int WIDTH = 1280;
    public static final int HEIGHT = 720;

    public CrearJugador() {

        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
//        this.setBackground(Color.BLACK);
        this.setLayout(null);
    }

}
