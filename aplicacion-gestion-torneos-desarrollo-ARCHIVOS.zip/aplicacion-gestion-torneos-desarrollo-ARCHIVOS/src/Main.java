import clases.Equipo;
import clases.Jugador;
import clases.Torneo;
import clases.TorneoCounter;
import clases.TorneoLol;
import clases.TorneoValorant;
import clases.TorneoDota;
import clases.Manejoarchivos;
import gui.CrearJugador;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.*;

import static clases.Manejoarchivos.*;


public class Main {
    public static void main(String[] args) throws IOException {

        Equipo[] Equipo = new Equipo[8];

        Equipo equipo1 = new Equipo(1,"Cyber Dragons","Alexia Rodríguez",10,2);
        Equipo equipo2 = new Equipo(2,"Shadow Reapers","Juan Carlos Medina",17,3);
        Equipo equipo3 = new Equipo(3,"Galactic Guardians","Samantha Lee",14,10);
        Equipo equipo4 = new Equipo(4,"Phoenix Fury","Rafael Gutiérrez",29,12);
        Equipo equipo5 = new Equipo(5,"Mystic Titans","María López",30,20);
        Equipo equipo6 = new Equipo(6,"Warlock Warriors","Gabriel Martínez",0,5);
        Equipo equipo7 = new Equipo(7,"Savage Sentinels","Andrea Torres",5,4);
        Equipo equipo8 = new Equipo(8,"Celestial Crusaders","Diego Ramírez",7,2);

        //Torneo torneo1 = new TorneoCounter("Copa Malacia","Riot","COUNTER",8,232, new String[]{"Eses"},"sese", new String[]{"esease"},Equipo,2332,"32324",323);

        Torneo torneo1 = new TorneoLol();
        Torneo torneo2 = new TorneoCounter();
        Torneo torneo3 = new TorneoValorant();
        Torneo torneo4 = new TorneoDota();
        Torneo torneo5 = new TorneoValorant();
        Torneo torneo6 = new TorneoDota();
        Torneo torneo7 = new TorneoCounter();
        Torneo torneo8 = new TorneoLol();
        Torneo torneo9 = new TorneoCounter();
        Torneo torneo10 = new TorneoLol();
        Torneo torneo11 = new TorneoDota();

        torneo1.setNombre("Torneo internacional de lol");
        torneo2.setNombre("Torneo Internacional de Counter Strike");
        torneo3.setNombre("Copa Mundial de Valorant");
        torneo4.setNombre("Dota league");
        torneo5.setNombre("Copa Mundial de Valorant");
        torneo6.setNombre("Dota league");
        torneo7.setNombre("Torneo Internacional de Counter Strike");
        torneo8.setNombre("Torneo internacional de lol");
        torneo9.setNombre("Torneo Internacional de Counter Strike");
        torneo10.setNombre("Torneo internacional de lol");
        torneo11.setNombre("Dota league");


       creararchivo("ResultadoTorneo.txt");

        escribirarchivo("ResultadoTorneo.txt","Torneo1 Nombre: " + torneo1.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo2 Nombre: " + torneo2.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo3 Nombre: " + torneo3.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo4 Nombre: " + torneo4.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo5 Nombre: " + torneo5.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo6 Nombre: " + torneo6.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo7 Nombre: " + torneo7.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo8 Nombre: " + torneo8.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo9 Nombre: " + torneo9.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo10 Nombre: " + torneo10.getNombre());
        escribirarchivo("ResultadoTorneo.txt","Torneo11 Nombre: " + torneo10.getNombre());




        //leerarchivo("ResultadoTorneo.txt");

        //eliminararchivo("ResultadoTorneo.txt");

        devolvervalores("ResultadoTorneo.txt", 19);






    }
}
